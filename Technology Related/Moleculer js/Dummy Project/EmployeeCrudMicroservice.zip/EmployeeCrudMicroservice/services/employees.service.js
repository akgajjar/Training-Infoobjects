"use strict";

const { MoleculerClientError } = require("moleculer").Errors;
const empController = require("../controller/employeeController.js");
const validationMixins = require("../utils/validations.utility.js");
/**
 * employees service
 */
module.exports = {
	name: "employees",

	/**
	 * Service settings
	 */
	settings: {
		validator: true,
	},

	mixins: [validationMixins],

	/**
	 * Service metadata
	 */
	metadata: {},

	/**
	 * Service dependencies
	 */
	dependencies: [],

	hooks: {
		before: {
			"*": [
				"checkFname",
				"checkMname",
				"checkLname",
				"checkMobileNo",
				"checkEmailId",
			],
		},
	},

	/**
	 * Actions
	 */
	actions: {
		create: {
			// Parameters definitions to validator
			params: {
				Emp_Fname: { type: "string", min: 2, max: 15 },
				Emp_Mname: { type: "string", min: 2, max: 15 },
				Emp_Lname: { type: "string", min: 2, max: 15 },
				Emp_Mobile_No: { type: "string", min: 2, max: 15 },
				Emp_Email_Id: { type: "string", min: 2, max: 50 },
			},
			handler(ctx) {
				return new Promise((resolve, reject) => {
					empController
						.create(ctx)
						.then((res) => {
							resolve(res);
						})
						.catch((err) => {
							throw new MoleculerClientError(
								"Error in Create Employee.",
								err.code,
								"employeeAPI",
								err
							);
						});
				});
			},
		},

		update: {
			// Parameters definitions to validator
			params: {
				//id: { type: "number", integer: true, positive: true },
				Emp_Fname: { type: "string", min: 2, max: 15 },
				Emp_Mname: { type: "string", min: 2, max: 15 },
				Emp_Lname: { type: "string", min: 2, max: 15 },
				Emp_Mobile_No: { type: "string", min: 2, max: 15 },
				Emp_Email_Id: { type: "string", min: 2, max: 50 },
			},
			handler(ctx) {
				return new Promise((resolve, reject) => {
					empController
						.update(ctx)
						.then((res) => {
							resolve(res);
						})
						.catch((err) => {
							throw new MoleculerClientError(
								"Error in Update Employee.",
								err.code,
								"employeeAPI",
								err
							);
						});
				});
			},
		},

		remove: {
			// Parameters definitions to validator
			params: {
				id: { type: "number", integer: true, positive: true },
			},
			handler(ctx) {
				return new Promise((resolve, reject) => {
					empController
						.remove(ctx)
						.then((res) => {
							resolve(res);
						})
						.catch((err) => {
							throw new MoleculerClientError(
								"Error in Delete Employee.",
								err.code,
								"employeeAPI",
								err
							);
						});
				});
			},
		},

		list() {
			return new Promise((resolve, reject) => {
				empController
					.list()
					.then((res) => {
						resolve(res);
					})
					.catch((err) => {
						throw new MoleculerClientError(
							"Error in List Employees.",
							err.code,
							"employeeAPI",
							err
						);
					});
			});
		},

		get: {
			// Parameters definitions to validator
			params: {
				id: { type: "number", integer: true, positive: true },
			},
			handler(ctx) {
				return new Promise((resolve, reject) => {
					empController
						.get(ctx)
						.then((res) => {
							resolve(res);
						})
						.catch((err) => {
							throw new MoleculerClientError(
								"Error in Get Employee.",
								err.code,
								"employeeAPI",
								err
							);
						});
				});
			},
		},

		getByTechId: {
			// Parameters definitions to validator
			params: {
				Tech_Id: { type: "number", integer: true, positive: true },
			},
			handler(ctx) {
				return new Promise((resolve, reject) => {
					empController
						.getByTechId(ctx)
						.then((res) => {
							resolve(res);
						})
						.catch((err) => {
							console.log(err);
							throw new MoleculerClientError(
								"Error in Get Employees By Tech Id.",
								err.code,
								"employeeAPI",
								err
							);
						});
				});
			},
		},

	},

	/**
	 * Events
	 */
	events: {},

	/**
	 * Methods
	 */
	methods: {},

	/**
	 * Service created lifecycle event handler
	 */
	created() {},

	/**
	 * Service started lifecycle event handler
	 */
	async started() {},

	/**
	 * Service stopped lifecycle event handler
	 */
	async stopped() {},
};
