const empService = require("../common/employeeCrudService.js");

var empController = {};

empController.create = async (ctx) => {
	const employee = {
		Emp_Fname: ctx.params.Emp_Fname,
		Emp_Mname: ctx.params.Emp_Mname,
		Emp_Lname: ctx.params.Emp_Lname,
		Emp_Mobile_No: ctx.params.Emp_Mobile_No,
		Emp_Email_Id: ctx.params.Emp_Email_Id,
	};
	const insertedEmployee = await empService.create(employee);

	let response = null;
	if (insertedEmployee != null) {
		response = {
			Inserted_Employee: insertedEmployee,
			Message: "Employee is Successfully Inserted",
		};
	} else {
		response = {
			Inserted_Employee: insertedEmployee,
			Message: "Error While Inserting Employee",
		};
	}
	return response;
};

empController.update = async (ctx) => {
	const employee = {
		Emp_Fname: ctx.params.Emp_Fname,
		Emp_Mname: ctx.params.Emp_Mname,
		Emp_Lname: ctx.params.Emp_Lname,
		Emp_Mobile_No: ctx.params.Emp_Mobile_No,
		Emp_Email_Id: ctx.params.Emp_Email_Id,
	};
	const updatedEmployee = await empService.update(employee, ctx.params.id);

	let response = null;
	if (updatedEmployee != null) {
		response = {
			Updated_Employee: updatedEmployee,
			Message: "Employee is Successfully Updated",
		};
	} else {
		response = {
			Updated_Employee: updatedEmployee,
			Message: "Error While Updating Employee",
		};
	}
	return response;
};

empController.remove = async (ctx) => {
	const deletedEmployee = await empService.remove(ctx.params.id);

	let response = null;
	if (deletedEmployee != null) {
		response = {
			Deleted_Employee: deletedEmployee,
			Message: "Employee is Successfully Deleted",
		};
	} else {
		response = {
			Deleted_Employee: deletedEmployee,
			Message: "Error While Deleting Employee",
		};
	}
	return response;
};

empController.list = async () => {
	const employees = await empService.list();

	let response = null;
	if (employees != null) {
		response = {
			Employees: employees,
			Message: "Employees is Successfully Selected",
		};
	} else {
		response = {
			Employees: employees,
			Message: "Error While Selecting Employees",
		};
	}
	return response;
};

empController.get = async (ctx) => {
	const employee = await empService.get(ctx.params.id);

	let response = null;
	if (employee != null) {
		response = {
			Employee: employee,
			Message: "Employee is Successfully Selected",
		};
	} else {
		response = {
			Employee: employee,
			Message: "Error While Selecting Employee",
		};
	}
	return response;
};

empController.getByTechId = async (ctx) => {
	let response = await ctx
		.call("employeeTechnologies.getEmpIds", { Tech_Id: ctx.params.Tech_Id })

	var employees = [];
	for (employeeTechnogy of response.Employee_Ids) {
		let employee = await ctx
			.call("employees.get", { id: employeeTechnogy.Emp_Id })
		employees.push(employee);
	}
	return employees;
};

module.exports = empController;
