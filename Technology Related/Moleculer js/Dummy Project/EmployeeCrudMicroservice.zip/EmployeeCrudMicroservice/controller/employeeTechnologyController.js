const empTechService = require("../common/employeeTechnologyService.js");

var empTechController = {};

empTechController.create = async (ctx) => {
	const employeeTechnology = {
		Tech_Id: ctx.params.Tech_Id,
		Emp_Id: ctx.params.Emp_Id,
	};
	const insertedEmployeeTechnology = await empTechService.create(
		employeeTechnology
	);

	let response = null;
	if (insertedEmployeeTechnology != null) {
		response = {
			Inserted_Employee_Technology: insertedEmployeeTechnology,
			Message: "EmployeeTechnology is Successfully Inserted",
		};
	} else {
		response = {
			Inserted_Employee_Technology: insertedEmployeeTechnology,
			Message: "Error While Inserting EmployeeTechnology",
		};
	}
	return response;
};

empTechController.update = async (ctx) => {
	const oldEmployeeTechnology = {
		Tech_Id: ctx.params.oldEmployeeTechnology.Tech_Id,
		Emp_Id: ctx.params.oldEmployeeTechnology.Emp_Id,
	};
	const newEmployeeTechnology = {
		Tech_Id: ctx.params.newEmployeeTechnology.Tech_Id,
		Emp_Id: ctx.params.newEmployeeTechnology.Emp_Id,
	};
	const updatedEmployeeTechnology = await empTechService.update(
		oldEmployeeTechnology,
		newEmployeeTechnology
	);

	let response = null;
	if (updatedEmployeeTechnology != null) {
		response = {
			Updated_Employee_Technology: updatedEmployeeTechnology,
			Message: "EmployeeTechnology is Successfully Updated",
		};
	} else {
		response = {
			Updated_Employee_Technology: updatedEmployeeTechnology,
			Message: "Error While Updating EmployeeTechnology",
		};
	}
	return response;
};

empTechController.remove = async (ctx) => {
	const employeeTechnology = {
		Tech_Id: ctx.params.Tech_Id,
		Emp_Id: ctx.params.Emp_Id,
	};
	const deletedEmployeeTechnology = await empTechService.remove(
		employeeTechnology
	);

	let response = null;
	if (deletedEmployeeTechnology != null) {
		response = {
			Deleted_Employee_Technology: deletedEmployeeTechnology,
			Message: "Technology is Successfully Deleted",
		};
	} else {
		response = {
			Deleted_Employee_Technology: deletedEmployeeTechnology,
			Message: "Error While Deleting EmployeeTechnology",
		};
	}
	return response;
};

empTechController.list = async () => {
	const employeeTechnologies = await empTechService.list();

	let response = null;
	if (employeeTechnologies != null) {
		response = {
			Employee_Technologies: employeeTechnologies,
			Message: "EmployeeTechnologies is Successfully Selected",
		};
	} else {
		response = {
			Employee_Technologies: employeeTechnologies,
			Message: "Error While Selecting EmployeeTechnologies",
		};
	}
	return response;
};

empTechController.getEmpIds = async (ctx) => {
	const employeeIds = await empTechService.getEmpIds(ctx.params.Tech_Id);

	let response = null;
	if (employeeIds != null) {
		response = {
			Employee_Ids: employeeIds,
			Message: "Employee Ids is Successfully Selected",
		};
	} else {
		response = {
			Employee_Ids: employeeIds,
			Message: "Error While Selecting Employee Ids",
		};
	}
	return response;
};

empTechController.getTechIds = async (ctx) => {
	const technologyIds = await empTechService.getTechIds(ctx.params.Emp_Id);

	let response = null;
	if (technologyIds != null) {
		response = {
			Technology_Ids: technologyIds,
			Message: "Technology Ids is Successfully Selected",
		};
	} else {
		response = {
			Technology_Ids: technologyIds,
			Message: "Error While Selecting Technology Ids",
		};
	}
	return response;
};

module.exports = empTechController;
