const techService = require("../common/technologyCrudService.js");

var techController = {};

techController.create = async (ctx) => {
	const technology = {
		Tech_Name: ctx.params.Tech_Name,
		Tech_Description: ctx.params.Tech_Name,
	};
	const insertedTechnology = await techService.create(technology);

	let response = null;
	if (insertedTechnology != null) {
		response = {
			Inserted_Technology: insertedTechnology,
			Message: "Technology is Successfully Inserted",
		};
	} else {
		response = {
			Inserted_Technology: insertedTechnology,
			Message: "Error While Inserting Technology",
		};
	}
	return response;
};

techController.update = async (ctx) => {
	const technology = {
		Tech_Name: ctx.params.Tech_Name,
		Tech_Description: ctx.params.Tech_Name,
	};
	const updatedTechnology = await techService.update(
		technology,
		ctx.params.id
	);

	let response = null;
	if (updatedTechnology != null) {
		response = {
			Updated_Technology: updatedTechnology,
			Message: "Technology is Successfully Updated",
		};
	} else {
		response = {
			Updated_Technology: updatedTechnology,
			Message: "Error While Updating Technology",
		};
	}
	return response;
};

techController.remove = async (ctx) => {
	const deletedTechnology = await techService.remove(ctx.params.id);

	let response = null;
	if (deletedTechnology != null) {
		response = {
			Deleted_Technology: deletedTechnology,
			Message: "Technology is Successfully Deleted",
		};
	} else {
		response = {
			Deleted_Technology: deletedTechnology,
			Message: "Error While Deleting Technology",
		};
	}
	return response;
};

techController.list = async () => {
	const technologies = await techService.list();

	let response = null;
	if (technologies != null) {
		response = {
			Technologies: technologies,
			Message: "Technologies is Successfully Selected",
		};
	} else {
		response = {
			Technologies: technologies,
			Message: "Error While Selecting Technologies",
		};
	}
	return response;
};

techController.get = async (ctx) => {
	const technology = await techService.get(ctx.params.id);

	let response = null;
	if (technology != null) {
		response = {
			Technology: technology,
			Message: "Technology is Successfully Selected",
		};
	} else {
		response = {
			Technology: technology,
			Message: "Error While Selecting Technology",
		};
	}
	return response;
};

techController.getByEmpId = async (ctx) => {
		let response = await ctx.call("employeeTechnologies.getTechIds", {
			Emp_Id: ctx.params.Emp_Id,
		});

		var technologies = [];
		for (employeeTechnogy of response.Technology_Ids) {
			let technology = await ctx.call("technologies.get", {
				id: employeeTechnogy.Tech_Id,
			});
			technologies.push(technology);
		}
		return technologies;
};

module.exports = techController;
