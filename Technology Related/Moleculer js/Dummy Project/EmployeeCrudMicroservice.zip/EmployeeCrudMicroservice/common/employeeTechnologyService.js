const knex = require("../utils/knexPools/createKnexPGPool");
const epConfig = require("../epConfig.js");
const knexConfig = epConfig.pgSqlConfig;

var empTechCrudService = {};

empTechCrudService.create = async (employeeTechnology) => {
	const insertedEmployeeTechnology = await knex
		.withSchema(knexConfig.schema)
		.table("Employee_Technology")
		.returning("*")
		.insert(employeeTechnology)
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Inserting EmployeeTechnology" +
					err
			);
		});
	if (insertedEmployeeTechnology != null) {
		console.log(
			"EmployeeTechnology Inserted : " +
				JSON.stringify(insertedEmployeeTechnology)
		);
		return insertedEmployeeTechnology;
	}
	return null;
};

empTechCrudService.update = async (
	oldEmployeeTechnology,
	newEmployeeTechnology
) => {
	const updatedEmployeeTechnology = await knex
		.withSchema(knexConfig.schema)
		.table("Employee_Technology")
		.returning("*")
		.where("Emp_Id", "=", oldEmployeeTechnology.Emp_Id)
		.where("Tech_Id", "=", oldEmployeeTechnology.Tech_Id)
		.update(newEmployeeTechnology)
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Updating EmployeeTechnology" +
					err
			);
		});
	if (updatedEmployeeTechnology != null) {
		console.log(
			"EmployeeTechnology Updated : " +
				JSON.stringify(updatedEmployeeTechnology)
		);
		return updatedEmployeeTechnology;
	}
	return null;
};

empTechCrudService.remove = async (employeeTechnology) => {
	const deletedEmployeeTechnology = await knex
		.withSchema(knexConfig.schema)
		.table("Employee_Technology")
		.returning("*")
		.where("Emp_Id", "=", employeeTechnology.Emp_Id)
		.where("Tech_Id", "=", employeeTechnology.Tech_Id)
		.delete()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Deleting EmployeeTechnology" +
					err
			);
		});
	if (deletedEmployeeTechnology != null) {
		console.log(
			"EmployeeTechnology Deleted : " +
				JSON.stringify(deletedEmployeeTechnology)
		);
		return deletedEmployeeTechnology;
	}
	return null;
};

empTechCrudService.list = async () => {
	const employeeTechnologies = await knex
		.withSchema(knexConfig.schema)
		.table("Employee_Technology")
		.returning("*")
		.select()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Selecting EmployeeTechnologies" +
					err
			);
		});
	if (employeeTechnologies != null) {
		console.log(
			"EmployeeTechnologies Selected : " +
				JSON.stringify(employeeTechnologies)
		);
		return employeeTechnologies;
	}
	return null;
};

empTechCrudService.getEmpIds = async (techId) => {
	const empIds = await knex
		.withSchema(knexConfig.schema)
		.table("Employee_Technology")
		.returning("*")
		.where("Tech_Id", "=", techId)
		.select()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Selecting Employee Ids" + err
			);
		});
	if (empIds != null) {
		console.log("Employee Ids Selected : " + JSON.stringify(empIds));
		return empIds;
	}
	return null;
};

empTechCrudService.getTechIds = async (empId) => {
	const techIds = await knex
		.withSchema(knexConfig.schema)
		.table("Employee_Technology")
		.returning("*")
		.where("Emp_Id", "=", empId)
		.select()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Selecting Technolgy Ids" +
					err
			);
		});
	if (techIds != null) {
		console.log("Technolgy Ids Selected : " + JSON.stringify(techIds));
		return techIds;
	}
	return null;
};

module.exports = empTechCrudService;
