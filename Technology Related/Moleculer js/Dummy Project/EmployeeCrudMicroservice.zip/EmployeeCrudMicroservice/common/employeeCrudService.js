const knex = require("../utils/knexPools/createKnexPGPool");
const epConfig = require("../epConfig.js");
const knexConfig = epConfig.pgSqlConfig;

var empCrudService = {};

empCrudService.create = async (employee) => {
	const insertedEmployee = await knex
		.withSchema(knexConfig.schema)
		.table("Employee")
		.returning("*")
		.insert(employee)
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Inserting Employee" + err
			);
		});
	if (insertedEmployee != null) {
		console.log("Employee Inserted : " + JSON.stringify(insertedEmployee));
		return insertedEmployee;
	}
	return null;
};

empCrudService.update = async (employee, empId) => {
	const updatedEmployee = await knex
		.withSchema(knexConfig.schema)
		.table("Employee")
		.returning("*")
		.where("Emp_Id", "=", empId)
		.update(employee)
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Updating Employee" + err
			);
		});
	if (updatedEmployee != null) {
		console.log("Employee Updated : " + JSON.stringify(updatedEmployee));
		return updatedEmployee;
	}
	return null;
};

empCrudService.remove = async (empId) => {
	deletedEmployee = await knex
		.withSchema(knexConfig.schema)
		.table("Employee")
		.returning("*")
		.where("Emp_Id", "=", empId)
		.delete()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Deleting Employee" + err
			);
		});
	if (deletedEmployee != null) {
		console.log("Employee Deleted : " + JSON.stringify(deletedEmployee));
		return deletedEmployee;
	}
	return null;
};

empCrudService.list = async () => {
	const employees = await knex
		.withSchema(knexConfig.schema)
		.table("Employee")
		.returning("*")
		.select()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Selecting Employees" + err
			);
		});

	if (employees != null) {
		console.log("Employees Selected : " + JSON.stringify(employees));
		return employees;
	}
	return null;
};

empCrudService.get = async (empId) => {
	const employee = await knex
		.withSchema(knexConfig.schema)
		.table("Employee")
		.returning("*")
		.where("Emp_Id", "=", empId)
		.select()
		.catch(function (err) {
			console.log("Error in executing knex query for Selecting Employee" + err);
		});
	if (employee != null) {
		console.log("Employee Selected : " + JSON.stringify(employee));
		return employee;
	}
	return null;
};

module.exports = empCrudService;
