const knex = require("../utils/knexPools/createKnexPGPool");
const epConfig = require("../epConfig.js");
const knexConfig = epConfig.pgSqlConfig;

var techCrudService = {};

techCrudService.create = async (technology) => {
	const insertedTechnology = knex
		.withSchema(knexConfig.schema)
		.table("Technology")
		.returning("*")
		.insert(technology)
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Inserting Technology" + err
			);
		});
	if (insertedTechnology != null) {
		console.log("Technology Inserted : " + JSON.stringify(insertedTechnology));
		return insertedTechnology;
	}
	return null;
};

techCrudService.update = async (technology, techId) => {
	const updatedTechnology = await knex
		.withSchema(knexConfig.schema)
		.table("Technology")
		.returning("*")
		.where("Tech_Id", "=", techId)
		.update(technology)
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Updating Technology" + err
			);
		});
	if (updatedTechnology != null) {
		console.log("Technology Updated : " + JSON.stringify(updatedTechnology));
		return updatedTechnology;
	}
	return null;
};

techCrudService.remove = async (techId) => {
	const deletedTechnology = await knex
		.withSchema(knexConfig.schema)
		.table("Technology")
		.returning("*")
		.where("Tech_Id", "=", techId)
		.delete()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Deleting Technology" + err
			);
		});
	if (deletedTechnology != null) {
		console.log(
			"Technology Deleted : " + JSON.stringify(deletedTechnology)
		);
		return deletedTechnology;
	}
	return null;
};

techCrudService.list = async () => {
	const technologies = await knex
		.withSchema(knexConfig.schema)
		.table("Technology")
		.returning("*")
		.select()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Selecting Technologies" + err
			);
		});

	if (technologies != null) {
		console.log("Technologies Selected : " + JSON.stringify(technologies));
		return technologies;
	}
	return null;
};

techCrudService.get = async (techId) => {
	const technology = await knex
		.withSchema(knexConfig.schema)
		.table("Technology")
		.returning("*")
		.where("Tech_Id", "=", techId)
		.select()
		.catch(function (err) {
			console.log(
				"Error in executing knex query for Selecting Technology" + err
			);
		});
	if (technology != null) {
		console.log("Technology Selected : " + JSON.stringify(technology));
		return technology;
	}
	return null;
};

module.exports = techCrudService;
