const { MoleculerClientError } = require("moleculer").Errors;

module.exports = {
	methods: {
		checkFname(ctx) {
			if (ctx.params.Emp_Fname)
				if (!ctx.params.Emp_Fname.match("^[a-zA-Z ]+$"))
					throw new MoleculerClientError(
						"Parameters validation error!",
						422,
						"VALIDATION_ERROR",
						[
							{
								type: "stringOnly",
								message:
									"The 'Emp_Fname' field length must be Characters Only.",
								field: "Emp_Fname",
								nodeID: "EmployeeCrudMicroservice",
							},
						]
					);
		},

		checkMname(ctx) {
			if (ctx.params.Emp_Mname)
				if (!ctx.params.Emp_Mname.match("^[a-zA-Z ]+$"))
					throw new MoleculerClientError(
						"Parameters validation error!",
						422,
						"VALIDATION_ERROR",
						[
							{
								type: "stringOnly",
								message:
									"The 'Emp_Mname' field length must be Characters Only.",
								field: "Emp_Mname",
								nodeID: "EmployeeCrudMicroservice",
							},
						]
					);
		},

		checkLname(ctx) {
			if (ctx.params.Emp_Lname)
				if (!ctx.params.Emp_Lname.match("^[a-zA-Z ]+$"))
					throw new MoleculerClientError(
						"Parameters validation error!",
						422,
						"VALIDATION_ERROR",
						[
							{
								type: "stringOnly",
								message:
									"The 'Emp_Lname' field length must be Characters Only.",
								field: "Emp_Lname",
								nodeID: "EmployeeCrudMicroservice",
							},
						]
					);
		},

		checkMobileNo(ctx) {
			if (ctx.params.Emp_Mobile_No)
				if (!ctx.params.Emp_Mobile_No.match(/^[9876]\d{9}$/i))
					throw new MoleculerClientError(
						"Parameters validation error!",
						422,
						"VALIDATION_ERROR",
						[
							{
								type: "Invalid Mobile No",
								message: "The 'Emp_Mobile_No' Is Not Valid.",
								field: "Emp_Mobile_No",
								nodeID: "EmployeeCrudMicroservice",
							},
						]
					);
		},

		checkEmailId(ctx) {
			if (ctx.params.Emp_Email_Id)
				if (
					!ctx.params.Emp_Email_Id.match(
						/^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,3}$/i
					)
				)
					throw new MoleculerClientError(
						"Parameters validation error!",
						422,
						"VALIDATION_ERROR",
						[
							{
								type: "Invalid Email Id",
								message: "The 'Emp_Email_Id' Is not valid .",
								field: "Emp_Email_Id",
								nodeID: "EmployeeCrudMicroservice",
							},
						]
					);
		},

		checkTechName(ctx) {

		},

	},
};
